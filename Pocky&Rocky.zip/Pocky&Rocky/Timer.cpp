#include "Timer.h"
Timer* Timer::unica_instancia = NULL;
Timer::Timer() {

}
Timer::~Timer()
{
}

void Timer::Start()
{
}
